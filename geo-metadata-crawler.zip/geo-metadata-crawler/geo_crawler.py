#!/usr/bin/env python3
"""
geo_crawler.py — Portable GEO (Gene Expression Omnibus) metadata crawler.

Discovers GEO Series (GSE) metadata via the NCBI E-utilities API and stores it
in a local SQLite3 database. Incremental by default; supports backfill of
existing records and a sync report.

Pure Python 3 standard library — no third-party dependencies.

Usage:
    # Daily incremental sync (default organisms: human, mouse, rat) + report
    python3 geo_crawler.py

    # Custom organisms and limits
    python3 geo_crawler.py --organisms "Homo sapiens" "Danio rerio" --max 2000

    # Backfill: re-fetch and update existing records (e.g. after adding fields)
    python3 geo_crawler.py --backfill

    # Report only, no crawling
    python3 geo_crawler.py --report-only --hours 24

    # Custom database location
    python3 geo_crawler.py --db /path/to/geo_metadata.db

Environment variables:
    NCBI_EMAIL      Contact email for NCBI (politely required by NCBI policy)
    NCBI_API_KEY    NCBI API key (raises rate limit from 1 to 3 req/s)
    GEO_METADATA_DB Default database path (overridden by --db)
"""

import argparse
import json
import os
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

EUTILS_BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
DEFAULT_DB = os.getenv("GEO_METADATA_DB", "geo_metadata.db")
DEFAULT_ORGANISMS = ["Homo sapiens", "Mus musculus", "Rattus norvegicus"]
PAGE_SIZE = 500          # esearch results per page
SUMMARY_BATCH = 100      # uids per esummary request
MAX_RETRIES = 3

# Column order — defines the gse_metadata table schema
DB_COLUMNS = [
    "accession", "title", "summary", "organism", "publish_date", "entry_type",
    "last_update", "sample_count", "parent_gse", "relation_type", "uid", "gds",
    "gpl", "gse", "gdstype", "suppfile", "samples_list", "ftplink", "geo2r",
    "bioproject", "pubmedids", "projects",
]

_last_request_time = 0.0


def _rate_limit_sleep():
    """Enforce NCBI rate limits: 3 req/s with API key, ~1 req/s without."""
    api_key = os.getenv("NCBI_API_KEY")
    min_interval = 0.35 if api_key else 1.05
    elapsed = time.monotonic() - _last_request_time
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)


def eutils_get(endpoint, params):
    """GET an E-utilities endpoint with retries and exponential backoff."""
    global _last_request_time
    params = dict(params)
    params.setdefault("tool", "geo-metadata-crawler")
    email = os.getenv("NCBI_EMAIL")
    if email:
        params.setdefault("email", email)
    api_key = os.getenv("NCBI_API_KEY")
    if api_key:
        params.setdefault("api_key", api_key)

    url = f"{EUTILS_BASE}/{endpoint}?{urllib.parse.urlencode(params)}"
    backoff = 2
    for attempt in range(MAX_RETRIES):
        _rate_limit_sleep()
        _last_request_time = time.monotonic()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "geo-metadata-crawler"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
            if attempt == MAX_RETRIES - 1:
                raise
            print(f"  ! Request failed ({e}); retrying in {backoff}s...", file=sys.stderr)
            time.sleep(backoff)
            backoff *= 2


def init_db(conn):
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS gse_metadata (
            accession     TEXT PRIMARY KEY,
            title         TEXT,
            summary       TEXT,
            organism      TEXT,
            publish_date  TEXT,
            entry_type    TEXT,
            last_update   TEXT,
            sample_count  INTEGER,
            parent_gse    TEXT,
            relation_type TEXT,
            uid           TEXT,
            gds           TEXT,
            gpl           TEXT,
            gse           TEXT,
            gdstype       TEXT,
            suppfile      TEXT,
            samples_list  TEXT,
            ftplink       TEXT,
            geo2r         TEXT,
            bioproject    TEXT,
            pubmedids     TEXT,
            projects      TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sync_state (
            organism         TEXT PRIMARY KEY,
            last_sync_date   TEXT,
            last_total_count INTEGER
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_gse_organism ON gse_metadata(organism)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_gse_pdat ON gse_metadata(publish_date)")
    conn.commit()


def get_last_sync_date(conn, organism):
    cur = conn.execute("SELECT last_sync_date FROM sync_state WHERE organism = ?", (organism,))
    row = cur.fetchone()
    return row[0] if row else "1900/01/01"


def update_sync_state(conn, organism, total_count):
    conn.execute("""
        INSERT INTO sync_state (organism, last_sync_date, last_total_count)
        VALUES (?, ?, ?)
        ON CONFLICT(organism) DO UPDATE SET
            last_sync_date = excluded.last_sync_date,
            last_total_count = excluded.last_total_count
    """, (organism, time.strftime("%Y/%m/%d"), total_count))
    conn.commit()


def get_existing_accessions(conn):
    try:
        return {r[0] for r in conn.execute("SELECT accession FROM gse_metadata")}
    except sqlite3.OperationalError:
        return set()


def esearch(term, retmax, retstart=0):
    data = eutils_get("esearch.fcgi", {"db": "gds", "term": term,
                                       "retmax": retmax, "retstart": retstart,
                                       "retmode": "json"})
    result = data["esearchresult"]
    return int(result["count"]), result["idlist"]


def record_from_summary(s):
    """Map an esummary JSON record onto DB_COLUMNS."""
    samples = s.get("samples") or []
    sample_count = s.get("n_samples")
    if sample_count is None:
        sample_count = len(samples)
    return {
        "accession": str(s.get("accession", "")),
        "title": str(s.get("title", "")),
        "summary": str(s.get("summary", "")),
        "organism": str(s.get("taxon", "")),
        "publish_date": str(s.get("pdat", "")),
        "entry_type": str(s.get("entrytype", "")),
        "last_update": None,
        "sample_count": int(sample_count),
        "parent_gse": None,
        "relation_type": None,
        "uid": str(s.get("uid", "")),
        "gds": str(s.get("gds", "")),
        "gpl": str(s.get("gpl", "")),
        "gse": str(s.get("gse", "")),
        "gdstype": str(s.get("gdstype", "")),
        "suppfile": str(s.get("suppfile", "")),
        "samples_list": ";".join(x.get("accession", "") for x in samples),
        "ftplink": str(s.get("ftplink", "")),
        "geo2r": str(s.get("geo2r", "")),
        "bioproject": str(s.get("bioproject", "")),
        "pubmedids": ";".join(str(p) for p in (s.get("pubmedids") or [])),
        "projects": ";".join(str(p) for p in (s.get("projects") or [])),
    }


def fetch_summaries(uids):
    """Fetch esummary records in batches; returns list of DB-column dicts."""
    records = []
    for i in range(0, len(uids), SUMMARY_BATCH):
        batch = uids[i:i + SUMMARY_BATCH]
        data = eutils_get("esummary.fcgi", {"db": "gds", "id": ",".join(batch),
                                            "retmode": "json"})
        for uid in data.get("result", {}).get("uids", []):
            s = data["result"][uid]
            if str(s.get("entrytype", "")).upper() == "GSE":
                records.append(record_from_summary(s))
    return records


def upsert(conn, records):
    if not records:
        return 0
    # Preserve manually-set parent_gse / relation_type on conflict
    update_cols = [c for c in DB_COLUMNS if c not in ("accession", "parent_gse", "relation_type")]
    set_clause = ", ".join(f"{c}=excluded.{c}" for c in update_cols)
    cols = ", ".join(DB_COLUMNS)
    ph = ", ".join("?" * len(DB_COLUMNS))
    sql = f"INSERT INTO gse_metadata ({cols}) VALUES ({ph}) ON CONFLICT(accession) DO UPDATE SET {set_clause}"
    conn.executemany(sql, [tuple(r[c] for c in DB_COLUMNS) for r in records])
    conn.commit()
    return len(records)


def sync_organism(conn, organism, max_records=5000, backfill=False, start=0):
    min_date = None
    if not backfill:
        min_date = get_last_sync_date(conn, organism)
        # 2-day buffer for NCBI Entrez indexing lag (embargo lifts may take
        # ~24h to appear). Upserts make re-processing safe.
        if min_date and min_date != "1900/01/01":
            buffered = datetime.strptime(min_date, "%Y/%m/%d") - timedelta(days=2)
            min_date = buffered.strftime("%Y/%m/%d")

    query = f'("{organism}"[porgn] AND gse[Filter])'
    if min_date and min_date != "1900/01/01":
        query += f' AND ("{min_date}"[PDAT] : "3000/12/31"[PDAT])'

    print(f"[{organism}] Searching...")
    total_found, _ = esearch(query, retmax=0)
    limit = min(total_found, max_records) if not backfill else total_found
    print(f"[{organism}] Found {total_found} records; crawling {start}..{limit}"
          + (" (BACKFILL)" if backfill else ""))

    existing = set() if backfill else get_existing_accessions(conn)
    processed = 0
    for page_start in range(start, limit, PAGE_SIZE):
        print(f"[{organism}] Page {page_start}..{page_start + PAGE_SIZE}")
        try:
            _, uids = esearch(query, retmax=PAGE_SIZE, retstart=page_start)
        except Exception as e:
            print(f"  ! esearch failed: {e}", file=sys.stderr)
            time.sleep(5)
            continue
        if not uids:
            break
        uids = uids[: limit - page_start]  # honor --max exactly
        try:
            summaries = fetch_summaries(uids)
        except Exception as e:
            print(f"  ! esummary failed: {e}", file=sys.stderr)
            time.sleep(5)
            continue
        if backfill:
            final = summaries
        else:
            final = [s for s in summaries if s["accession"] not in existing]
        n = upsert(conn, final)
        processed += n
        if not backfill:
            existing.update(s["accession"] for s in final)
        print(f"[{organism}] Checkpoint: {processed} records written this run.")

    update_sync_state(conn, organism, total_found)
    print(f"[{organism}] Sync complete.")
    return processed


def report(conn, organisms, hours=48):
    total = conn.execute("SELECT COUNT(*) FROM gse_metadata").fetchone()[0]
    cutoff = time.strftime("%Y-%m-%d", time.gmtime(time.time() - hours * 3600))
    print("\n--- GEO METADATA SYNC REPORT ---")
    print(f"Database: {conn.execute('PRAGMA database_list').fetchone()[2]}")
    print(f"Total rows in gse_metadata: {total}")
    for org in organisms:
        n = conn.execute("SELECT COUNT(*) FROM gse_metadata WHERE organism LIKE ?",
                         (f"%{org}%",)).fetchone()[0]
        print(f"Rows matching '{org}': {n}")
    new_rows = conn.execute(
        """SELECT accession, title FROM gse_metadata
           WHERE publish_date >= ? ORDER BY publish_date DESC, accession DESC""",
        (cutoff,)).fetchall()
    print(f"Records with publish_date >= {cutoff} (lookback {hours}h): {len(new_rows)}")
    for acc, title in new_rows[:10]:
        t = (title or "").replace("\n", " ")
        print(f"- {acc}: {t[:80]}")
    if len(new_rows) > 10:
        print(f"... and {len(new_rows) - 10} more.")


def main():
    ap = argparse.ArgumentParser(description="Portable GEO metadata crawler (SQLite3)")
    ap.add_argument("--organisms", nargs="+", default=DEFAULT_ORGANISMS,
                    help="Organisms to crawl (default: human mouse rat)")
    ap.add_argument("--db", default=DEFAULT_DB,
                    help=f"SQLite database path (default: {DEFAULT_DB})")
    ap.add_argument("--max", type=int, default=5000,
                    help="Max records per organism per run (default: 5000)")
    ap.add_argument("--hours", type=int, default=48,
                    help="Lookback window for the report (default: 48)")
    ap.add_argument("--start", type=int, default=0,
                    help="Start index within result list (default: 0)")
    ap.add_argument("--backfill", action="store_true",
                    help="Re-fetch and update existing records (ignores date filter)")
    ap.add_argument("--report-only", action="store_true",
                    help="Skip crawling; print the report only")
    args = ap.parse_args()

    if not os.getenv("NCBI_EMAIL"):
        print("NOTE: Set NCBI_EMAIL for NCBI contact policy compliance.", file=sys.stderr)

    conn = sqlite3.connect(args.db)
    try:
        init_db(conn)
        if not args.report_only:
            before = conn.execute("SELECT COUNT(*) FROM gse_metadata").fetchone()[0]
            for org in args.organisms:
                sync_organism(conn, org, max_records=args.max,
                              backfill=args.backfill, start=args.start)
            after = conn.execute("SELECT COUNT(*) FROM gse_metadata").fetchone()[0]
            print(f"\nNew rows this run: {after - before}")
        report(conn, args.organisms, hours=args.hours)
    finally:
        conn.close()


if __name__ == "__main__":
    main()

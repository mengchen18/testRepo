# geo-metadata-crawler

Portable crawler for GEO (Gene Expression Omnibus) dataset metadata.
Fetches GEO Series (GSE) records from the NCBI E-utilities API into a local
SQLite3 database. Python 3.8+ standard library only — copy this folder to any
machine and run it.

## Files

- `geo_crawler.py` — the crawler (single self-contained script)
- `SKILL.md` — full usage documentation, schema, cron examples

## Usage

```bash
# Set your contact email (NCBI policy) and optionally an API key
export NCBI_EMAIL=you@example.com
export NCBI_API_KEY=...          # optional, 3 req/s instead of 1 req/s

# Daily incremental sync (default: human, mouse, rat) + report
python3 geo_crawler.py

# Options
python3 geo_crawler.py --organisms "Danio rerio" --db /data/geo.db --max 2000
python3 geo_crawler.py --report-only --hours 24
python3 geo_crawler.py --backfill
```

Output is a single SQLite file (`geo_metadata.db` by default) with tables
`gse_metadata` and `sync_state`. Query with `sqlite3` or any SQLite client.

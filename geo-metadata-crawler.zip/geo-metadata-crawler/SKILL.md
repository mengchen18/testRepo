---
name: geo-metadata-crawler
description: |
  Portable crawler for GEO (Gene Expression Omnibus) dataset metadata via the
  NCBI E-utilities API. Discovers GEO Series (GSE) records and stores them in
  a local SQLite3 database. No external services, no third-party Python
  dependencies — works on any machine with Python 3 (3.8+).

## Invocation Criteria

Invoke this skill when the user:
- Wants to crawl / discover GEO dataset metadata (GSE records)
- Asks for a GEO metadata database or daily GEO sync on a new machine
- Mentions "geo metadata", "gse metadata", "geo crawler", "geo sync"

Do NOT invoke this skill when the user:
- Wants to download/ingest actual GEO data files (metadata only here)
- Wants to query an existing database (plain SQLite, see Schema below)

## Quick Start

```bash
cd /path/to/skill/dir

# Daily incremental sync (human, mouse, rat) + report
python3 geo_crawler.py

# Custom organisms, custom DB location
python3 geo_crawler.py --organisms "Danio rerio" "Homo sapiens" --db /data/geo.db

# Report only (no crawling)
python3 geo_crawler.py --report-only --hours 24

# Backfill: re-fetch all records to refresh/update fields (slow, full history)
python3 geo_crawler.py --backfill
```

The database is a single portable SQLite file (`geo_metadata.db` by default).
Default database path can also be set via the `GEO_METADATA_DB` env var.

## Environment Variables

| Variable         | Purpose                                            |
|------------------|----------------------------------------------------|
| `NCBI_EMAIL`     | Contact email (NCBI policy politely requires this) |
| `NCBI_API_KEY`   | NCBI API key — raises rate limit 1 req/s → 3 req/s |
| `GEO_METADATA_DB`| Default DB path if `--db` is not given             |

## How It Works

1. **esearch** on NCBI `db=gds` with term `("<organism>"[porgn] AND gse[Filter])`
   — optionally date-filtered by `PDAT`.
2. Paginates UIDs (500/page), fetches details via **esummary** (100 IDs/request).
3. Upserts records into `gse_metadata` (PRIMARY KEY `accession`; conflict
   updates all fields except `parent_gse`/`relation_type`, which are reserved
   for manual curation).
4. Tracks per-organism progress in `sync_state`.
5. Prints a sync report (totals per organism + new records in lookback window).

**Incremental sync & indexing lag:** each run advances `last_sync_date`, and
the next run re-scans from 2 days *before* that date (Entrez indexing lag for
newly public datasets). Upserts make re-processing idempotent, so this is safe.

**Rate limiting:** built-in (0.35 s/request with API key, 1.05 s without),
with retries and exponential backoff on transient HTTP errors.

## First Run (Bootstrap)

The first run on a fresh database starts from `last_sync_date = 1900/01/01`,
so the query has **no date filter** and covers the organism's entire history,
subject to `--max` (default 5000 = the newest 5000 records per organism).

Once the run finishes, `sync_state` is set to today, and every subsequent run
is incremental (PDAT filter + 2-day overlap buffer). **Re-running the default
command does NOT continue the historical crawl** — it only picks up new
records going forward.

**To build a complete historical database**, do a one-time full crawl with a
high limit (larger than the organism's total record count):

```bash
python3 geo_crawler.py --max 1000000   # one-time full crawl, all organisms
```

- Check the `Found N records` line in the output for actual totals
  (human/mouse each have ~100k+ GSE records as of 2026).
- Expect roughly 2,800 API requests total: ~45–60 min without an API key
  (1 req/s) or ~15–20 min with one (3 req/s).

**If a full crawl is interrupted**, `sync_state` has not yet advanced, so a
plain re-run would restart from 0. Resume instead from the last processed
offset:

```bash
# first run stopped after "Processing page 45000..45500"
python3 geo_crawler.py --start 45000 --max 1000000
```

`--start` is an offset into the unfiltered result list and only makes sense
while `sync_state` still predates the crawl (i.e., during bootstrap).

**`--backfill` is different:** it re-fetches *all* records to refresh existing
rows (e.g. after new fields were added to the schema) — it ignores both
`--max` and the date filter and performs a full crawl with upserts.

## CLI Reference

```
--organisms NAME [NAME ...]  Organisms to crawl (default: "Homo sapiens"
                             "Mus musculus" "Rattus norvegicus")
--db PATH                    SQLite database path (default: ./geo_metadata.db
                             or $GEO_METADATA_DB)
--max N                      Max records per organism per run (default: 5000)
--hours N                    Report lookback window (default: 48)
--start N                    Start index in result list (resume an
                             interrupted bootstrap crawl; see First Run)
--backfill                   Ignore date filter and --max; re-fetch and
                             refresh all existing records
--report-only                Skip crawling; print report only
```

## Database Schema

**`gse_metadata`** (one row per GSE accession):

| Column         | Source (esummary) / Notes                    |
|----------------|----------------------------------------------|
| accession      | `accession` (e.g. GSE123456, PRIMARY KEY)    |
| title          | `title`                                      |
| summary        | `summary`                                    |
| organism       | `taxon`                                      |
| publish_date   | `pdat` (format `YYYY/MM/DD`)                 |
| entry_type     | `entrytype`                                  |
| last_update    | reserved (currently NULL)                    |
| sample_count   | `n_samples`                                  |
| parent_gse     | reserved for manual curation                 |
| relation_type  | reserved for manual curation                 |
| uid            | `uid` (gds UID)                              |
| gds, gpl, gse  | `gds` / `gpl` / `gse` ids                    |
| gdstype        | `gdstype` (study type)                       |
| suppfile       | `suppfile` (supplementary file types)        |
| samples_list   | `;`-joined GSM accessions                    |
| ftplink        | `ftplink` (FTP directory)                    |
| geo2r          | `geo2r`                                      |
| bioproject     | `bioproject`                                 |
| pubmedids      | `;`-joined PubMed ids                        |
| projects       | `;`-joined projects                          |

**`sync_state`**: `organism` (PK), `last_sync_date`, `last_total_count`.

## Cron Example

```cron
# Daily GEO metadata sync at 06:00, log per day
0 6 * * * cd /path/to/geo-metadata-crawler && \
  NCBI_EMAIL=you@example.com python3 geo_crawler.py \
  >> logs/sync_$(date +\%Y-\%m-\%d).log 2>&1
```

(Use `flock -n /tmp/geo_crawler.lock ...` if overlapping runs are possible.)

## Example Queries

```bash
sqlite3 geo_metadata.db "SELECT COUNT(*) FROM gse_metadata"

sqlite3 geo_metadata.db "SELECT accession, sample_count, publish_date, title
  FROM gse_metadata
  WHERE gdstype LIKE '%high throughput sequencing%'
    AND sample_count >= 6
  ORDER BY publish_date DESC LIMIT 10"
```

## Error Handling

- **HTTP 429 / transient errors** — automatic retry (3 attempts, exp. backoff)
- **Partial page failure** — page skipped with warning, run continues
- **Duplicates** — impossible by primary key; upsert keeps data fresh
- **First run / incomplete history** — see [First Run (Bootstrap)](#first-run-bootstrap):
  the default first run only fetches the newest 5000 records per organism;
  use a one-time `--max 1000000` crawl for full history

## Portability Notes

- Python 3.8+ standard library only (urllib, json, sqlite3)
- No docker, no external database, no SSH, no absolute paths
- Database is one file — copy/move it freely; back it up with `cp` or
  `sqlite3 db ".backup backup.db"`
